<?php
	  $xh=$_POST['xuehao'];
	  $xm=$_POST['xingming'];
	  $xb=$_POST['xingbie'];
	  $yx=$_POST['yuanxi'];
	  $lh=$_POST['louhao'];
	  $qh=$_POST['qinhao'];
	  $sj=$_POST['shijian'];
	  //1.连接数据库
	  $con=mysqli_connect('localhost:3306','root','');
	  //2.选择数据库
	  mysqli_select_db($con,'student');
	  //3.执行数据库
	  mysqli_query($con,'set names utf8');
      $q="insert into stu values('$xh','$xm','$xb','$yx','$lh','$qh','$sj')";
      if(mysqli_query($con,$q)){
         echo '添加学生打卡信息成功！';
      }else{
         echo'添加学生打卡信息失败！';
          }
	  //4.关闭数据库
	  mysqli_close($con);
		  
?>

