<?php
      $id=$_GET['xuehao'];
   //1.连接数据库
      $con=mysqli_connect('localhost:3306','root','');
   //2.选择数据库
      mysqli_select_db($con,'student');
   //3.执行数据库
      mysqli_query($con,'set names utf8');
      $q="delete from stu where stuID='$id'";
      $result=mysqli_query($con,$q);
      if($result){
        echo'删除成功！';
      }else{
        echo'删除失败！';
      }
   //4.关闭数据库
     mysqli_close($con);
		  
?>



