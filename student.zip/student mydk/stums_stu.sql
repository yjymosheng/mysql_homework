drop table  if exists stu;
create table stu(
	stuname varchar(20) not null,
	stuid varchar(20) not null primary key,
	stusex varchar(10) default 'man',
	stubirth date ,
	stuclass varchar(50) 
)engine=innoDB;

drop table  if exists admin;
create table admin(
	admname varchar(20) not null,
	admid varchar(20) not null primary key,
	admsex varchar(10) default 'man',
	admbirth date ,
	admmanage varchar(50)
)engine=innoDB;

