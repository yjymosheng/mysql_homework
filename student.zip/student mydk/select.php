<?php
      $id=$_POST['xuehao'];
   //1.连接数据库
      $con=mysqli_connect('localhost:3306','root','');
   //2.选择数据库
      mysqli_select_db($con,'student');
   //3.执行数据库
      mysqli_query($con,'set names utf8');
          $q="select * from stu where stuID='$id'";
          $result=mysqli_query($con,$q);
          echo mysqli_fetch_array($result)['stuName'];
   //4.关闭数据库
     mysqli_close($con);
		  
?>

