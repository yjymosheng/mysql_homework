<?php
$host = '127.0.0.1';
$user = 'root';
$port = '3306';
$pass = 'root';
$db   = 'library';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die('连接失败: ' . $conn->connect_error);
}

// 处理新增
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $isbn = $_POST['isbn'];
    $description = $_POST['description'];
    $status = $_POST['status'];
    $stmt = $conn->prepare("INSERT INTO books (title, author, isbn, description, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $title, $author, $isbn, $description, $status);
    $stmt->execute();
    $stmt->close();
    header("Location: index.php");
    exit;
}

// 处理删除
if (isset($_GET['delete'])) {
    $book_id = intval($_GET['delete']);
    $conn->query("DELETE FROM books WHERE book_id = $book_id");
    header("Location: index.php");
    exit;
}

// 处理更新
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $book_id = intval($_POST['book_id']);
    $title = $_POST['title'];
    $author = $_POST['author'];
    $isbn = $_POST['isbn'];
    $description = $_POST['description'];
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE books SET title=?, author=?, isbn=?, description=?, status=? WHERE book_id=?");
    $stmt->bind_param("sssssi", $title, $author, $isbn, $description, $status, $book_id);
    $stmt->execute();
    $stmt->close();
    header("Location: index.php");
    exit;
}

// 获取数据
$books = $conn->query("SELECT * FROM books");

// 编辑模式
$editing = null;
if (isset($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    $edit_result = $conn->query("SELECT * FROM books WHERE book_id = $edit_id");
    if ($edit_result->num_rows > 0) {
        $editing = $edit_result->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>图书管理系统</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 30px; }
        th, td { border: 1px solid #ccc; padding: 8px 12px; text-align: left; }
        th { background: #f2f2f2; }
        form { margin-bottom: 20px; }
        input[type=text], textarea, select {
            width: 100%; padding: 8px; margin: 4px 0; box-sizing: border-box;
        }
        input[type=submit] { padding: 8px 16px; }
    </style>
</head>
<body>
    <h1>图书管理系统</h1>

    <h2><?php echo $editing ? '编辑图书' : '新增图书'; ?></h2>
    <form method="post">
        <?php if ($editing): ?>
            <input type="hidden" name="book_id" value="<?php echo $editing['book_id']; ?>">
        <?php endif; ?>
        <label>书名: <input type="text" name="title" required value="<?php echo $editing['title'] ?? ''; ?>"></label><br>
        <label>作者: <input type="text" name="author" required value="<?php echo $editing['author'] ?? ''; ?>"></label><br>
        <label>ISBN: <input type="text" name="isbn" value="<?php echo $editing['isbn'] ?? ''; ?>"></label><br>
        <label>简介:<br><textarea name="description"><?php echo $editing['description'] ?? ''; ?></textarea></label><br>
        <label>状态:
            <select name="status">
                <option value="available" <?php echo ($editing['status'] ?? '') === 'available' ? 'selected' : ''; ?>>可借</option>
                <option value="checked_out" <?php echo ($editing['status'] ?? '') === 'checked_out' ? 'selected' : ''; ?>>已借出</option>
            </select>
        </label><br>
        <input type="submit" name="<?php echo $editing ? 'update' : 'add'; ?>" value="<?php echo $editing ? '更新' : '添加'; ?>">
        <?php if ($editing): ?>
            <a href="index.php">取消编辑</a>
        <?php endif; ?>
    </form>

    <h2>图书列表</h2>
    <table>
        <tr>
            <th>ID</th><th>书名</th><th>作者</th><th>ISBN</th><th>简介</th><th>状态</th><th>操作</th>
        </tr>
        <?php if ($books->num_rows > 0): ?>
            <?php while ($row = $books->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['book_id']; ?></td>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['author']); ?></td>
                    <td><?php echo htmlspecialchars($row['isbn']); ?></td>
                    <td><?php echo htmlspecialchars($row['description']); ?></td>
                    <td><?php echo $row['status'] === 'available' ? '可借' : '已借出'; ?></td>
                    <td>
                        <a href="?edit=<?php echo $row['book_id']; ?>">编辑</a> |
                        <a href="?delete=<?php echo $row['book_id']; ?>" onclick="return confirm('确认删除这本书吗？')">删除</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="7">暂无图书</td></tr>
        <?php endif; ?>
    </table>
</body>
</html>
<?php $conn->close(); ?>
